# CodeAlpha Handwritten Character Recognition

## Objective
Identify handwritten digits using Deep Learning and CNN.

## Technologies Used
- Python
- TensorFlow
- Keras
- NumPy
- Matplotlib

## Dataset
- MNIST Dataset

## Model
- Convolutional Neural Network (CNN)

## Features
- Image preprocessing
- CNN training
- Digit prediction
- Accuracy graph
- Model saving

## Run Project

Install dependencies:

pip install -r requirements.txt

Run project:

python main.py
