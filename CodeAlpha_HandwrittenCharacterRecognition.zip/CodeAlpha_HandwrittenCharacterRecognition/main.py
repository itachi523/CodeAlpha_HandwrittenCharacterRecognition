import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D
from tensorflow.keras.layers import Flatten, Dense, Dropout
from tensorflow.keras.utils import to_categorical

print("TensorFlow Version:", tf.__version__)

# =========================
# LOAD DATASET
# =========================
(x_train, y_train), (x_test, y_test) = mnist.load_data()

# Show sample image
plt.imshow(x_train[0], cmap='gray')
plt.title(f"Label: {y_train[0]}")
plt.show()

# =========================
# PREPROCESSING
# =========================

# Normalize
x_train = x_train / 255.0
x_test = x_test / 255.0

# Reshape for CNN
x_train = x_train.reshape(-1, 28, 28, 1)
x_test = x_test.reshape(-1, 28, 28, 1)

# One-hot encoding
y_train = to_categorical(y_train, 10)
y_test = to_categorical(y_test, 10)

# =========================
# BUILD CNN MODEL
# =========================
model = Sequential([

    Conv2D(32, (3,3), activation='relu', input_shape=(28,28,1)),
    MaxPooling2D((2,2)),

    Conv2D(64, (3,3), activation='relu'),
    MaxPooling2D((2,2)),

    Flatten(),

    Dense(128, activation='relu'),
    Dropout(0.3),

    Dense(10, activation='softmax')
])

# =========================
# COMPILE MODEL
# =========================
model.compile(
    optimizer='adam',
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

model.summary()

# =========================
# TRAIN MODEL
# =========================
history = model.fit(
    x_train,
    y_train,
    epochs=5,
    validation_split=0.1
)

# =========================
# EVALUATE
# =========================
loss, accuracy = model.evaluate(x_test, y_test)

print("Test Accuracy:", accuracy * 100)

# =========================
# SAVE MODEL
# =========================
model.save("models/handwritten_model.h5")

# =========================
# PREDICTIONS
# =========================
predictions = model.predict(x_test)

# Display predictions
plt.figure(figsize=(12,12))

for i in range(25):

    plt.subplot(5,5,i+1)

    plt.xticks([])
    plt.yticks([])

    plt.imshow(x_test[i].reshape(28,28), cmap='gray')

    pred = np.argmax(predictions[i])

    plt.xlabel(f"Predicted: {pred}")

plt.tight_layout()
plt.show()

# =========================
# ACCURACY GRAPH
# =========================
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])

plt.title("Model Accuracy")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")

plt.legend(['Train', 'Validation'])

plt.savefig("outputs/accuracy_graph.png")
plt.show()
